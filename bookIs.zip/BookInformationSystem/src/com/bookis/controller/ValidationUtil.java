/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
package com.bookis.controller;
import com.BookIs.view.InformationPage;
import java.util.regex.Pattern;
*/
/**
 *
 * @author ajita
 */
/**
public class ValidationUtil {
   private static final Pattern NAME_PATTERN = Pattern.compile("^[a-zA-Z]+$");
   private static final Pattern ISBN_PATTERN = Pattern.compile("^\\d{7}$");
   */
   /**
     * Validates if a string is null or empty.
     *
     * @param value the string to validate
     * @return true if the string is null or empty, otherwise false
     */
/**
    public static boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }
    */
    /**
     * Validates if the name contains only alphabets.
     *
     * @param name the name to validate
     * @return true if valid, otherwise false
     */
/**
    public static boolean isValidName(String name) {
        return !isNullOrEmpty(name) && NAME_PATTERN.matcher(name).matches();
    }
*/
     /**
     * Validates if the ISBN is exactly 7 digits.
     *
     * @param isbn the ISBN to validate
     * @return true if valid, otherwise false
     */
/**
    public static boolean isValidISBN(int isbn) {
        return ISBN_PATTERN.matcher(String.valueOf(isbn)).matches();
    }
   
    
    
    
     
}
* /
