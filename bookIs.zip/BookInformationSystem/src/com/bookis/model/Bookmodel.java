/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.bookis.model;
/**
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;
*/

/**
 *
 * @author ajita
 */
public class Bookmodel {
    /**
    private final ArrayList <Bookmodel> BookList ;
     
    private DefaultTableModel defaultTableModel;
    
    */
    
    private String name;
    private int isbn;
    private int publishedYear;
    private int price;
    private String genre;
    
    public Bookmodel(){
        /**
     BookList = new ArrayList();
     addNewInitialBook(new Bookmodel("Palace Of Illusions", 9780667, 2008, 800, "Historical Fiction" ));
     addNewInitialBook(new Bookmodel("A Thousand Splendid Suns", 890989, 2007, 750, "Domestic Fiction" ));
     addNewInitialBook(new Bookmodel("Firfire", 876755, 2016, 778, "Fiction" ));
     addNewInitialBook(new Bookmodel("The Myth Of Sisyphus", 789808, 1942, 1000, "Philosophical Essay" ));
     addNewInitialBook(new Bookmodel("The Waves", 5068907, 1931, 1500, "Experimental Literature" ));
     */
     
    }
    
    public Bookmodel(String name, int isbn, int publishedYear, int price, String genre){
        this.name = name;
        this.isbn = isbn;
        this.publishedYear = publishedYear;
        this.price = price;
        this.genre = genre;
    }

    public String getName() {
        return name;
    }

    public int getIsbn() {
        return isbn;
    }

    public int getPublishedYear() {
        return publishedYear;
    }

    public int getPrice() {
        return price;
    }

    public String getGenre() {
        return genre;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }

    public void setPublishedYear(int publishedYear) {
        this.publishedYear = publishedYear;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }
    
    /**
   private void addNewInitialBook(Bookmodel book) {
       BookList.add(book);
       addDataToTable(book);
   }
    
  private void addDataToTable(Bookmodel book) {
        defaultTableModel = (DefaultTableModel) tblbook.getModel();
        defaultTableModel.addRow(new Object[]{book.getIsbn(),
            book.getName(), book.getPublishedYear(), book.getPrice(),
            book.getGenre()});
    } 
    private void addBookDataToTable(Bookmodel book){ BookList.add(book);
        
         defaultTableModel = (DefaultTableModel) tblbook.getModel();
          defaultTableModel.addRow(new Object[]{book.getIsbn(),
            book.getName(), book.getPublishedYear(), book.getPrice(),
            book.getGenre()});
       
          
}
 */
}
